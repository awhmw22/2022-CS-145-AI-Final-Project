from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import pandas as pd

def preprocess_data(df):
    # Strip column names to avoid whitespace issues
    df.columns = df.columns.str.strip()

    # Print the columns to verify existence of necessary data
    print("Columns in the dataset:", df.columns)

    # Drop irrelevant columns
    df = df.drop(columns=["Name"], errors='ignore')  # Drop 'Name' column

    # Handle missing values
    if df.isnull().sum().any():
        print("Missing values found. Dropping rows with missing values...")
        df = df.dropna()

    # Ensure essential columns exist
    required_columns = ['Household Income (PKR)', 'Region', 'Occupation', 'Poverty Indicators']
    missing_columns = [col for col in required_columns if col not in df.columns]
    if missing_columns:
        raise KeyError(f"Missing columns in the dataset: {missing_columns}")

    # Focus on relevant columns
    df = df[required_columns]

    # Handle target variable: Poverty Indicators
    print("Unique values in 'Poverty Indicators':", df['Poverty Indicators'].unique())
    target_mapping = {"High": 1, "Low": 0, "Medium": 2}
    df['Poverty Indicators'] = df['Poverty Indicators'].map(target_mapping)

    # Drop rows with invalid target values (NaN after mapping)
    if df['Poverty Indicators'].isnull().any():
        print(f"Dropping rows with invalid 'Poverty Indicators' values...")
        df = df.dropna(subset=['Poverty Indicators'])

    # One-hot encode categorical variables
    categorical_cols = ['Region', 'Occupation']
    encoder = OneHotEncoder(sparse_output=False, drop="first")
    encoded_data = pd.DataFrame(
        encoder.fit_transform(df[categorical_cols]),
        columns=encoder.get_feature_names_out(categorical_cols),
        index=df.index
    )

    # Combine numeric and encoded data
    numeric_cols = ['Household Income (PKR)']
    processed_df = pd.concat([df[numeric_cols], encoded_data], axis=1)

    # Prepare target variable (y)
    y = df['Poverty Indicators'].astype(int)

    # Debug output
    print(f"Processed dataset shape: {processed_df.shape}")
    print(f"Shape of X: {processed_df.shape}, Shape of y: {y.shape}")

    # Split the dataset
    X_train, X_test, y_train, y_test = train_test_split(processed_df, y, test_size=0.2, random_state=42)

    # Scale numeric features
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    return X_train, X_test, y_train, y_test

# Load and preprocess the dataset
file_path = "Poverty_Assessment_Tool_Data_Cleaned.xlsx"
df = pd.read_excel(file_path)
X_train, X_test, y_train, y_test = preprocess_data(df)
