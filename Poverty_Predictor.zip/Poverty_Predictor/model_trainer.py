from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import pandas as pd
from preprocessor import preprocess_data

# Train the RandomForestClassifier
def train_model(X_train, y_train, n_estimators=100, max_depth=None):
    """
    Train a RandomForestClassifier.
    Args:
        X_train: Training features.
        y_train: Training labels.
        n_estimators: Number of trees in the forest (default=100).
        max_depth: Maximum depth of the trees (default=None).
    Returns:
        Trained RandomForest model.
    """
    model = RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth, random_state=42)
    model.fit(X_train, y_train)
    return model

# Evaluate the model's performance
def evaluate_model(model, X_test, y_test):
    """
    Evaluate the model on test data.
    Args:
        model: Trained model.
        X_test: Test features.
        y_test: Test labels.
    Returns:
        Accuracy score.
    """
    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    print("Classification Report:")
    print(classification_report(y_test, predictions))
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, predictions))
    return accuracy

# Save the model using joblib
def save_model(model, file_name="poverty_model.pkl"):
    """
    Save the trained model to a file.
    Args:
        model: Trained model.
        file_name: File name to save the model.
    """
    joblib.dump(model, file_name)
    print(f"Model saved as '{file_name}'.")

# Load the model using joblib
def load_model(file_name="poverty_model.pkl"):
    """
    Load a trained model from a file.
    Args:
        file_name: File name to load the model from.
    Returns:
        Loaded model.
    """
    try:
        model = joblib.load(file_name)
        print(f"Model loaded from '{file_name}'.")
        return model
    except FileNotFoundError:
        print(f"Error: The file '{file_name}' does not exist.")
        return None

# Main execution
if __name__ == "__main__":
    # Load the data
    file_name = "Poverty_Assessment_Tool_Data_Cleaned.xlsx"
    df = pd.read_excel(file_name)

    # Preprocess the data
    X_train, X_test, y_train, y_test = preprocess_data(df)

    # Train the model
    print("Training the model...")
    model = train_model(X_train, y_train)

    # Evaluate the model
    print("Evaluating the model...")
    accuracy = evaluate_model(model, X_test, y_test)
    print(f"Model accuracy: {accuracy * 100:.2f}%")

    # Save the model
    save_model(model)

    # Load the model to verify saving/loading
    loaded_model = load_model()
    if loaded_model:
        loaded_model_accuracy = evaluate_model(loaded_model, X_test, y_test)
        print(f"Loaded model accuracy: {loaded_model_accuracy * 100:.2f}%")
