import pandas as pd

def load_data(file_name="Poverty_Assessment_Tool_Data_Cleaned.xlsx"):
    """
    Load dataset from the given file in the same folder.
    """
    return pd.read_excel(file_name)
