import streamlit as st
import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import joblib
import matplotlib.pyplot as plt
import numpy as np
import altair as alt

# Load the model
def load_model(file_name="poverty_model.pkl"):
    try:
        model = joblib.load(file_name)
        return model
    except FileNotFoundError:
        st.error(f"Model file '{file_name}' not found.")
        return None

# Preprocess user input
def preprocess_user_input(region, occupation, income, encoder, scaler):
    input_df = pd.DataFrame([[region, occupation, income]], columns=["Region", "Occupation", "Household Income (PKR)"])

    # One-hot encode 'Region' and 'Occupation' using the trained encoder
    encoded_input = pd.DataFrame(
        encoder.transform(input_df[["Region", "Occupation"]]),
        columns=encoder.get_feature_names_out(["Region", "Occupation"])
    )
    
    # Combine with numeric feature
    processed_input = pd.concat([input_df[["Household Income (PKR)"]], encoded_input], axis=1)

    # Ensure column names are in the same order as the training data (important for scaling)
    processed_input = processed_input.reindex(columns=scaler.feature_names_in_, fill_value=0)

    # Scale the input using the trained scaler
    scaled_input = scaler.transform(processed_input)
    return scaled_input

# Load and preprocess dataset for metadata
file_name = "Poverty_Assessment_Tool_Data_Cleaned.xlsx"
data = pd.read_excel(file_name)

# Train OneHotEncoder and StandardScaler on the original dataset
encoder = OneHotEncoder(sparse_output=False, drop="first")
encoded_features = encoder.fit_transform(data[["Region", "Occupation"]])

# Combine numeric and encoded data
numeric_data = data[["Household Income (PKR)"]]
combined_data = pd.concat([numeric_data, pd.DataFrame(encoded_features)], axis=1)
combined_data.columns = combined_data.columns.astype(str)

# Fit the StandardScaler
scaler = StandardScaler()
scaler.fit(combined_data)

# Load the model once for the app
model = load_model()

# Streamlit UI
st.title("Poverty Reduction Dashboard")
st.sidebar.header("Input Data")

# Admin Dashboard
st.sidebar.subheader("Admin Dashboard")
st.sidebar.write(f"Total Number of People: {data.shape[0]}")

# Average Income by Region
avg_income_by_region = data.groupby("Region")["Household Income (PKR)"].mean().reset_index()
st.sidebar.write("Average Household Income by Region:")
st.sidebar.dataframe(avg_income_by_region)

# Most Common Occupation by Region
most_common_occupation = data.groupby("Region")["Occupation"].agg(lambda x: x.value_counts().idxmax()).reset_index()
st.sidebar.write("Most Common Occupation by Region:")
st.sidebar.dataframe(most_common_occupation)

# User Input
region = st.sidebar.selectbox("Region", data["Region"].unique())
occupation = st.sidebar.selectbox("Occupation", data["Occupation"].unique())
# User Input (Textbox for Household Income)
income = st.sidebar.text_input("Average Household Income", value="0")

# Prediction
if st.sidebar.button("Predict"):
    if model:
        input_data = preprocess_user_input(region, occupation, income, encoder, scaler)
        prediction = model.predict(input_data)
        prediction_label = "High" if prediction[0] == 1 else "Low"
        st.write(f"Predicted Poverty Level: {prediction_label}")

        # Suggestions based on income, region, and occupation
        st.write("Suggestions:")

        # Income-based suggestions
        if int(income) < 30000:
            st.write("- **Increase Salary**: Consider seeking additional income sources or negotiating your salary.")
            st.write("- **Government Aid**: Look for financial assistance programs available for low-income families.")
        elif int(income) > 60000:
            st.write("- **Investments**: Consider investing in mutual funds, stocks, or real estate to grow your wealth.")
            st.write("- **Retirement Savings**: Start saving for retirement through pension plans or retirement funds.")
        else:
            st.write("- **Save for Emergencies**: It's important to have an emergency fund to cover unforeseen expenses.")

        # Region-based suggestions
        if region in ['Sindh', 'KPK']:
            st.write("- **Consider Relocation**: If opportunities in your region are limited, look for better opportunities in larger cities.")
            st.write("- **Local Government Schemes**: Investigate local government programs that can help support your income.")
        elif region in ['Punjab', 'Baluchistan']:
            st.write("- **Agriculture or Crafting**: Depending on the region, consider diversifying your income through local industries like farming or crafts.")
        
        # Occupation-based suggestions
        if occupation == 'Laborer':
            st.write("- **Skill Enhancement**: Look into upskilling programs that could qualify you for better-paying labor jobs.")
            st.write("- **Government Welfare**: Check if you qualify for public welfare schemes or laborer-specific subsidies.")
        elif occupation == 'Teacher':
            st.write("- **Education Grants**: Explore opportunities for further qualifications or teaching certifications.")
            st.write("- **Private Tutoring**: Consider taking private tutoring jobs or online classes to supplement your income.")
        elif occupation == 'Unemployed':
            st.write("- **Job Search**: Consider upskilling, learning a trade, or looking for job opportunities through online platforms.")
            st.write("- **Government Schemes for Unemployment**: Look for government-funded training programs or unemployment benefits.")

# Visualization: Pie Chart (Prediction Distribution)
st.subheader("Prediction Distribution (Pie Chart)")
if st.button("Show Prediction Distribution"):
    if model:
        # Get predictions for the entire dataset based on user input (region, occupation, and income)
        input_data = preprocess_user_input(region, occupation, income, encoder, scaler)
        poverty_levels = model.predict(input_data)
        
        # Calculate prediction distribution
        high_count = sum(poverty_levels == 1)
        low_count = sum(poverty_levels == 0)
        prediction_counts = {'High': high_count, 'Low': low_count}
        
        # Plot the pie chart with different colors for High and Low predictions
        fig, ax = plt.subplots()
        colors = ['#ff4c4c', '#4caf50']  # Red for 'High', Green for 'Low'
        ax.pie(prediction_counts.values(), labels=prediction_counts.keys(), autopct='%1.1f%%', startangle=90, colors=colors)
        ax.axis('equal')  # Equal aspect ratio ensures the pie chart is circular.
        st.pyplot(fig)

        # Add a comment below the chart
        st.markdown("This chart shows the distribution of poverty levels predicted by the model. "
                    "**High poverty levels** indicate more financial instability, while **low poverty levels** "
                    "suggest better financial conditions.")

# Visualization: Line Chart (Income vs Predicted Poverty Level)
st.subheader("Income vs Predicted Poverty Level (Line Chart)")
if st.button("Show Income vs Poverty Level"):
    if model:
        # Generate a range of income values for the line chart
        income_values = np.linspace(0, 100000, 100)

        # Create an empty dataframe with all features (including Region and Occupation)
        input_data = pd.DataFrame({
            'Household Income (PKR)': income_values,
            'Region': [region] * len(income_values),  # Use user-selected region
            'Occupation': [occupation] * len(income_values)  # Use user-selected occupation
        })

        # One-hot encode 'Region' and 'Occupation' based on the original encoder
        encoded_input = pd.DataFrame(
            encoder.transform(input_data[["Region", "Occupation"]]),
            columns=encoder.get_feature_names_out(["Region", "Occupation"])
        )

        # Combine with numeric feature
        processed_input = pd.concat([input_data[["Household Income (PKR)"]], encoded_input], axis=1)

        # Ensure the input matches the original columns the scaler expects
        processed_input = processed_input.reindex(columns=scaler.feature_names_in_, fill_value=0)

        # Scale the input data
        scaled_input = scaler.transform(processed_input)

        # Predict the poverty levels based on scaled input
        poverty_levels = model.predict(scaled_input)

        # Plot the line chart with hover effects using Altair
        import altair as alt
        df = pd.DataFrame({'Household Income (PKR)': income_values, 'Poverty Level': poverty_levels})
        line_chart = alt.Chart(df).mark_line(point=True).encode(
            x='Household Income (PKR)',
            y='Poverty Level',
            tooltip=['Household Income (PKR)', 'Poverty Level']
        ).properties(
            title=f"Income vs Predicted Poverty Level for {region} - {occupation}"
        )
        st.altair_chart(line_chart, use_container_width=True)

        # Add a comment below the chart
        st.markdown("This chart illustrates how predicted poverty levels vary with household income. "
                    "Hover over the points to view specific income and poverty level predictions.")

# Visualization: Bar Chart (Feature Importance)
st.subheader("Feature Importance (Bar Chart)")
if st.button("Show Feature Importance"):
    if model:
        feature_importances = model.feature_importances_
        feature_names = ["Household Income (PKR)"] + list(encoder.get_feature_names_out(["Region", "Occupation"]))
        
        # Plot the feature importances with Altair for interactivity
        feature_df = pd.DataFrame({'Feature': feature_names, 'Importance': feature_importances})
        bar_chart = alt.Chart(feature_df).mark_bar().encode(
            x='Importance:Q',
            y=alt.Y('Feature:N', sort='-x'),
            tooltip=['Feature', 'Importance']
        ).properties(
            title=f"Feature Importances for {region} - {occupation}"
        )
        st.altair_chart(bar_chart, use_container_width=True)

        # Add a comment below the chart
        st.markdown("This chart shows the importance of various features used in the model. "
                    "**Household Income** typically has the highest influence, while regional and occupational factors "
                    "also contribute significantly.")
